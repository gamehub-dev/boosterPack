// To start off
// link 'autoEngine.js' through your html file, make sure it is the first script that loads!!
// there will be instructions on how to use it next to whatever interest you.
// 
// you can also browse around this file to see its capabilities!
// hope this helps.


// to view engine version, type 'EngineVersion()' in the console.



























// classes
class Player{
    constructor(x, y, vy, vxl, vxr, w, h, s, j, f, g, c){
        this.x = x;
        this.y = y;
        this.vy = vy;
        this.vxl = vxl;
        this.vxr = vxr;
        this.w = w;
        this.h = h;
        this.speed = s;
        this.jumpSpeed = j;
        this.mass = f;
        this.g = g;
        this.c = c;
    }
}
let player = new Player(100, 100, 0, 0, 0, 50, 50, 5, 15, 0.2, false, "black")


class CalcDistanceX{
    constructor(x, y){
        this.x = x;
        this.y = y;
    }
}
let pointA = new CalcDistanceX(0, 0)
let pointB = new CalcDistanceX(0, 0)


class CanvasBorder{
    constructor(w, c){
        this.w = w
        this.c = c
    }
}
let border = new CanvasBorder(3, 'black')


// end of classes

// auto create canvas with 'canvas' as tag
// if not using canvas, removeCanvas = true
canv = document.createElement('canvas')
canv.id = 'canvas'
document.body.appendChild(canv)



const cl = console.log; // log text in the console
const ce = console.error // log an error
const cw = console.warn // log a warning
const ct = console.trace // trace something
const listen = addEventListener; // listen for an event
const canvas = document.getElementById('canvas'); // for ctx
const ctx = canvas.getContext('2d'); // for ctx
let bgc = 'white'; // change document background colour
const timeout = setTimeout; // create a timeout for an amount of time
const height = window.innerHeight; // the height of the document
const width = window.innerWidth; // the width of the document
const interval = setInterval; // create an interval
const doc = document;
let rand;
function random(max, min){
    rand = Math.floor(Math.random() * (max - min + 1)) + min
}
// generate random number and control the maximum and minimum by typing 'random(1 // min, 10 // max)'
let hideOverflow = false; // change value to 'true' to hide scroll bars.
let hideOverflowY = false; // change value to 'true' to hide the Y scroll bar.
let hideOverflowX = false; // change value to 'true' to hide the X scroll bar.
// if you individually hide each bar, then you will have to reverse both variable values to show scroll bars.
const anim = requestAnimationFrame;
let mouseX = 0; // Access the mouseX position
let mouseY = 0; // Access the mouseY position
let title = document.title; // change variable value to change document title
let removeCanvas = false; // if true, then the automatic canvas creation will not happen on startUp. Note: value cannot be reversed 
let calcDist = false; // to calculate the DistanceX between point A and B, you must first set 'calcDist = true'-
// then, set 'pointAx.x' to point A 'X', and 'pointBx.x' to point B 'X'.
// then use 'DistanceX' (variable) to see the DistanceX between point A and point B.
//to calculate the DistanceY between point A and B, set 'pointAy.y' to your point A 'Y', then-
// 'pointBy.y' to your point B 'Y'.
// then use 'DistanceY' (variable) to see the DistanceY between point A and point B.
// e.g:
// pointA.x = 20;
// pointB.x = 100; 
// calcDist = true;
// output would be 80px apart from each other on the X Axis

// e.g.
// pointA.y = 50;
// pointB.y = 200;
// calcDist = true;
// calcDist = true;
// output would be 150px apart from each other on the Y Axis

let borderCollision = false;
let borderWalls = false;
let gravity = false;


// How to draw a player
// 1) create function inside your main.js.
// 2) type 'requestAnimationFrame('Name of your function')', or 'anim('Name of function')'.
// 3) then type 'drawPlayer' inside that function.
// 4) Lastly, remember to call your function!



// private variables (not to be changed or used) 
let DistanceX;
let DistanceY;
let playerMovement = false;
// end

function borderCol(){
    if (player.x <= canvas.width - canvas.width){
        player.x = canvas.width - canvas.width;
    }
    if (player.x + player.w >= canvas.width){
        player.x = canvas.width - player.w - 1
    }
    if (player.y <= canvas.height - canvas.height){
        player.y = canvas.height - canvas.height;
    }
    if (player.y + player.h >= canvas.height){
        player.y = canvas.height - player.h
        player.g = true;
    }
}

// how to use:
// 1) create function inside your main.js.
// 2) type 'requestAnimationFrame('Name of function')', or 'anim('Name of function')'.
// 3) then type 'AllowPlayerMovement()' inside that function.
// 4) Lastly, remember to call your function!
// ============
// How to customize character:
// to resize the width and height, simply change the value (in your main.js) of player.w (player width) and/or player.h (player height).
// Default is 50 x 50;
// ============
// player movement
function AllowPlayerMovement(){
    playerMovement = true;
    ctx.clearRect(0, 0, width, height);
    player.x += player.vxl
    player.x += player.vxr
    player.y += player.vy
    if (borderCollision){
        borderCol()
    }
    ctx.fillStyle = player.c
    ctx.fillRect(player.x, player.y, player.w, player.h)
    anim(AllowPlayerMovement)
}
function drawPlayer(){ // not to be used if you are already using the engine's movement controls
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = player.c
    ctx.fillRect(player.x, player.y, player.w, player.h)

}
listen("keydown", function(e) {
    if (playerMovement){
    if (gravity == false){
    if (e.key == 'w') player.vy = -player.speed;
    if (e.key == 's') player.vy = player.speed;
    if (e.key == 'd') player.vxr = player.speed;
    if (e.key == 'a') player.vxl = -player.speed;
    }
    }
})
listen("keydown", function(e) {
    if (playerMovement){
        if (gravity){
            if (player.g){
    if (e.key == 'w') player.vy = -player.jumpSpeed, player.g = false;
            }
    if (e.key == 'd') player.vxr = player.speed;
    if (e.key == 'a') player.vxl = -player.speed;
        }
    }
})
listen("keyup", function (e) {
    if (playerMovement){
        if (gravity == false){
            if (e.key == 'w') player.vy = 0;
            if (e.key == 's') player.vy = 0;
            if (e.key == 'd') player.vxr = 0;
            if (e.key == 'a') player.vxl = 0;
    }
}
})
listen("keyup", function (e) {
    if (playerMovement){
        if (gravity){
            if (e.key == 'd') player.vxr = 0;
            if (e.key == 'a') player.vxl = 0;
    }
}
})
// end of charactor movement
listen("mousemove", function(e) {
    mouseX = e.clientX;
    mouseY = e.clientY;
})
setInterval(function MainEngineInterval() {
    if (hideOverflow){
        document.body.style.overflow = 'hidden';
    }
    if (hideOverflow == false){
        document.body.style.overflow = '';
    }
    if (hideOverflowX){
        document.body.style.overflowX = 'hidden'
    }
    if (hideOverflowX == false && document.body.style.overflow == false){
        document.body.style.overflowX = ''
    }
    if (hideOverflowY){
        document.body.style.overflowY = 'hidden'
    }
    if (hideOverflowY == false && document.body.style.overflow == false){
        document.body.style.overflowY = ''
    }
    document.title = title
    if (removeCanvas){
        canvas.remove()
        removeCanvas = false;
    }   
    if (calcDist){
        calcDist = false;
        DistanceX = pointB.x - pointA.x
        DistanceY = pointB.y - pointA.y
        if (DistanceX < -1){
            DistanceX = pointA.x - pointB.x
        }
        if (DistanceY < -1){
            DistanceY = pointA.y - pointA.y
        }
        console.log("DistanceX From 'pointA.x' (" + pointA.x + ")" + " to 'pointBx.x' (" + pointB.x + ") is: " + DistanceX + "px")
        console.log("===========")
        console.log("DistanceY From 'pointA.y' (" + pointA.y + ")" + " to 'pointB.y' (" + pointB.y + ") is: " + DistanceY + "px")
    }
    doc.body.style.backgroundColor = bgc   
function EngineVersion(){
    cl('The current Engine version that you have installed is:')
    cl('Version 1.3.1')
}
    if (borderWalls){
    canvas.style.border = border.w + 'px solid ' + border.c 
    }
    if (gravity){
        player.vy += player.mass
    }
})
canvas.width = width - 30;
canvas.height = height - 30;
cl("autoEngine.js Loaded Succesfully")
cl("Built by using autoEngine.js")